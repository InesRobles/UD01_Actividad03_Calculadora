package com.mycompany.calculadora

import java.util.Scanner

fun main() {
    val scan = Scanner(System.`in`)
    var opcion: Int

    do {
        // Fase 2
        println("\n===== CALCULADORA BÁSICA =====")
        println("1. Sumar")
        println("2. Restar")
        println("3. Multiplicar")
        println("4. Dividir")
        println("5. Calcular resto")
        println("6. Salir")
        print("Seleccione una opción: ")

        //Depuración
        if (!scan.hasNextInt()) {
            println("Opción no válida, introduce un número.")
            scan.next()
            opcion= 0
            continue
        }

        opcion=scan.nextInt()

        // Fase 5
        when (opcion) {
            1, 2, 3, 4, 5 -> {
                // Fase 3
                print("Primer número: ")
                while (!scan.hasNextDouble()) {
                    println("Error, introduce un valor numérico válido.")
                    scan.next()
                    print("Introduce el primer número: ")
                }
                val num1 = scan.nextDouble()

                print("Segundo número: ")
                while (!scan.hasNextDouble()) {
                    println("Error, introduce un valor numérico válido.")
                    scan.next()
                    print("Segundo número: ")
                }
                val num2 =scan.nextDouble()

                // Fase 4
                when (opcion){
                    1 ->{
                        val resultado =num1 + num2
                        println("La suma es: $resultado")
                    }
                    2 ->{
                        val resultado =num1 -num2
                        println("La resta es: $resultado")
                    }
                    3 ->{
                        val resultado =num1 * num2
                        println("La multiplicación es: $resultado")
                    }
                    4 ->{
                        if (num2 == 0.0){
                            println("Error, no se puede dividir entre cero.")
                        } else {
                            val resultado =num1 / num2
                            println("La división es: $resultado")
                        }
                    }
                    5 ->{
                        if (num2 == 0.0){
                            println("Error: no se puede calcular el resto entre cero.")
                        } else {
                            val resultado =num1 % num2
                            println("El resultado del resto es: $resultado")
                        }
                    }
                }
            }
            6 ->{
                println("Saliendo del programa. ¡Hasta pronto!")
            }
            else ->{
                println("Opción no válida")
            }
        }

    } while (opcion != 6)
    //Hasta que el usuario salga, el bucle se repite
}